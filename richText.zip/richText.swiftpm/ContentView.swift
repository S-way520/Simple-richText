import SwiftUI
struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello ") 
                .font(.largeTitle)
            + Text(
                Image(systemName: "star")
            ) 
            + Text(" World!")
        }
    }
}
 
